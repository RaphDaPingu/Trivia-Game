import socket
import binascii
import struct

def dict_to_binary(my_dict):
    binary_json = bin(int(binascii.hexlify(str(my_dict).encode()), 16))

    return (binary_json)

#client
SERVER_IP = "127.0.0.1"
SERVER_PORT = 8826

SIGNUP_CODE = 2
LOGIN_CODE = 1

SIGNUP_MESSAGE = '{"username": "user1", "password": "1234", "mail": "user1@gmail.com"}'
LOGIN_MESSAGE = '{"username": "user1", "password": "1234"}'

#example of signup

#msg = "{:08b}".format(SIGNUP_CODE, 2) + " " + "{:032b}".format(int(len(dict_to_binary(SIGNUP_MESSAGE).replace("b", "")) / 8), 2) + " " + dict_to_binary(SIGNUP_MESSAGE).replace("b", "")

#print(msg)

#example of login

#print()

#msg = "{:08b}".format(LOGIN_CODE, 2) + " " + "{:032b}".format(int(len(dict_to_binary(LOGIN_MESSAGE).replace("b", "")) / 8), 2) + " " + dict_to_binary(LOGIN_MESSAGE).replace("b", "")

#print(msg)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = (SERVER_IP, SERVER_PORT)

try:
    sock.connect(server_address)
    
except Exception as e:
    print("Error establishing connection with server\nError:", e)

msg = ""

try:
    print("Sending signup message...")

    print()

    msg = "{:08b}".format(SIGNUP_CODE, 2) + "{:032b}".format(len(SIGNUP_MESSAGE), 2) + SIGNUP_MESSAGE

    print(msg)

    #msg = ((str((SIGNUP_CODE).to_bytes(1, byteorder = "big"))).replace("b'", "")).replace("'", "") + ((str(len(SIGNUP_MESSAGE).to_bytes(4, byteorder = "big"))).replace("b'", "")).replace("'", "") + str(SIGNUP_MESSAGE)
    
    #print(msg)
    
    sock.sendall(msg.encode())
    
    server_msg = sock.recv(1024)
    #server_msg = server_msg.decode('base64')
    
    print("\nThe server sent back: " + str(server_msg))

    print("\nSending login message...")
    
    msg = "{:08b}".format(LOGIN_CODE, 2) + "{:032b}".format(len(LOGIN_MESSAGE), 2) + LOGIN_MESSAGE

    print(msg)

    #msg = ((str((LOGIN_CODE).to_bytes(1, byteorder = "big"))).replace("b'", "")).replace("'", "") + ((str(len(LOGIN_MESSAGE).to_bytes(4, byteorder = "big"))).replace("b'", "")).replace("'", "") + str(LOGIN_MESSAGE)

    #print(msg)

    sock.sendall(msg.encode())
    
    server_msg = sock.recv(1024)
    #server_msg = server_msg.decode('base64')
    
    print("\nThe server sent back: " + str(server_msg))

except Exception as e:
    print("\nError while communicating with server\nError:", e)

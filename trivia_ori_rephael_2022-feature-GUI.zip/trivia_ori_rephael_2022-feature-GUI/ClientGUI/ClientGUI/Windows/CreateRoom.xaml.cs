﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;
namespace ClientGUI.Windows
{
    /// <summary>
    /// Interaction logic for CreateRoom.xaml
    /// </summary>
    public partial class CreateRoom : Window
    {
        public CreateRoom()
        {
            InitializeComponent();

            this.Welcome.FontSize = 30;

            this.DisplayUsername.Content = SocketClass.username;
            this.DisplayUsername.FontSize = 15;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Create_Click(object sender, RoutedEventArgs e)
         {
            // database from server

            byte[] code = new byte[1];
            code[0] = (byte)(7);

            CreateRoomRequest roomReq = new CreateRoomRequest(RoomNameBox.Text, int.Parse(NumberOfPlayersBox.Text), 
                int.Parse(NumberOfQuestionsBox.Text), int.Parse(TimePerQuestionBox.Text));

            string json = JsonConvert.SerializeObject(roomReq, Formatting.Indented);

            byte[] lenBytes = new byte[json.Length];
            lenBytes = BitConverter.GetBytes(json.Length);

            byte[] data = Encoding.ASCII.GetBytes(json);

            byte[] msg = code.Concat(lenBytes).ToArray().Concat(data).ToArray();

            SocketClass.clientStream.Write(msg, 0, msg.Length);

            SocketClass.clientStream.Read(code, 0, 1);
            SocketClass.clientStream.Read(lenBytes, 0, 4);

            if (BitConverter.IsLittleEndian)
                Array.Reverse(lenBytes);

            byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
            SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

            string dataStr = Encoding.Default.GetString(dataRecv);

            this.Hide();

            Room win = new Room(RoomNameBox.Text);
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Window_Closed(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Threading;
using Newtonsoft.Json;

namespace ClientGUI.Windows
{
    /// <summary>
    /// Interaction logic for JoinRoom.xaml
    /// </summary>
    public partial class JoinRoom : Window
    {
        public JoinRoom()
        {
            InitializeComponent();

            this.Welcome.FontSize = 30;

            this.DisplayUsername.Content = SocketClass.username;
            this.DisplayUsername.FontSize = 15;

            this.RoomsList.FontSize = 20;

            // change to get list from server

            List<User> rooms = User.LoadCollectionData(); // change

            RoomsGrid.ItemsSource = rooms;
            RoomsGrid.DataContext = this;

            ThreadStart ts = new ThreadStart(Refresh);
            Thread t = new Thread(ts);
            t.IsBackground = false;
            t.Start();      
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            
            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;
            
            win.Show();
        }

        private void Refresh()
        {
            while (true)
            {
                bool isActive = false;
                Dispatcher.Invoke(() =>
                {
                    isActive = this.IsActive;
                        
                });
                if (!isActive)
                    break;

                byte[] code = new byte[1];
                code[0] = (byte)(5);

                SocketClass.clientStream.Write(code, 0, code.Length);

                byte[] lenBytes = new byte[4];
                SocketClass.clientStream.Read(code, 0, 1);
                SocketClass.clientStream.Read(lenBytes, 0, 4);

                if (BitConverter.IsLittleEndian)
                    Array.Reverse(lenBytes);

                byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
                SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

                string data = Encoding.Default.GetString(dataRecv);
                Dictionary<string, int> rooms = JsonConvert.DeserializeObject<Dictionary<string, int>>(data);

                if (rooms.Values.First() != 0)
                {
                    Dispatcher.Invoke(() =>
                    {
                        RoomsGrid.DataContext = rooms;
                    });
                }
                Thread.Sleep(3000);
            }
        }
        private void RoomsGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var grid = sender as DataGrid;
            var cellValue = grid.SelectedValue;
            grid.SelectedValue.ToString().Split();

            RoomsList.Content = cellValue; // change

            byte[] code = new byte[1];
            code[0] = (byte)(7);

            JoinRoomRequest joinRoomReq = new JoinRoomRequest(1);
            string json = JsonConvert.SerializeObject(joinRoomReq, Formatting.Indented);

            byte[] lenBytes = new byte[json.Length];
            lenBytes = BitConverter.GetBytes(json.Length);

            byte[] data = Encoding.ASCII.GetBytes(json);

            byte[] msg = code.Concat(lenBytes).ToArray().Concat(data).ToArray();

            SocketClass.clientStream.Write(msg, 0, msg.Length);

            SocketClass.clientStream.Read(code, 0, 1);
            SocketClass.clientStream.Read(lenBytes, 0, 4);

            if (BitConverter.IsLittleEndian)
                Array.Reverse(lenBytes);

            byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
            SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

            string dataStr = Encoding.Default.GetString(dataRecv);

            this.Hide();

            Room win = new Room(cellValue.ToString());
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Window_Closed(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;
namespace ClientGUI.Windows
{
    /// <summary>
    /// Interaction logic for BestScores.xaml
    /// </summary>
    public partial class BestScores : Window
    {
        public BestScores()
        {
            InitializeComponent();

            this.Welcome.FontSize = 30;

            this.DisplayUsername.Content = SocketClass.username;
            this.DisplayUsername.FontSize = 15;

            this.User1.FontSize = 20;
            this.User2.FontSize = 20;
            this.User3.FontSize = 20;

            byte[] code = new byte[1];
            code[0] = (byte)(9);

            SocketClass.clientStream.Write(code, 0, code.Length);

            byte[] lenBytes = new byte[4];
            SocketClass.clientStream.Read(code, 0, 1);
            SocketClass.clientStream.Read(lenBytes, 0, 4);

            if (BitConverter.IsLittleEndian)
                Array.Reverse(lenBytes);

            byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
            SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

            string data = Encoding.Default.GetString(dataRecv);
            Dictionary<string, int> scores = JsonConvert.DeserializeObject<Dictionary<string, int>>(data);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Window_Closed(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;
using Newtonsoft.Json;

namespace ClientGUI.Windows
{
    /// <summary>
    /// Interaction logic for Room.xaml
    /// </summary>
    public partial class Room : Window
    {
        public Room(string roomname)
        {
            InitializeComponent();

            this.Welcome.FontSize = 30;

            this.DisplayUsername.Content = SocketClass.username;
            this.DisplayUsername.FontSize = 15;

            // change to get list from server
            RoomWelcome.Content = "You are connected to room: " + roomname;

            byte[] code = new byte[1];
            code[0] = (byte)(13);

            SocketClass.clientStream.Write(code, 0, code.Length);

            byte[] lenBytes = new byte[4];
            SocketClass.clientStream.Read(code, 0, 1);
            SocketClass.clientStream.Read(lenBytes, 0, 4);

            if (BitConverter.IsLittleEndian)
                Array.Reverse(lenBytes);

            byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
            SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

            string data = Encoding.Default.GetString(dataRecv);
            GetRoomStateResponse roomState = JsonConvert.DeserializeObject<GetRoomStateResponse>(data);

            RoomInfo.Content = "number__of__questions: " + roomState.questionCount + ", time__per__question: " + roomState.answerTimeout;
            ParticipantsGrid.Items.Add(roomState.players);

            ThreadStart ts = new ThreadStart(Refresh);
            Thread t = new Thread(ts);

            t.IsBackground = false;
            t.Start();
        }
        private void Refresh()
        {
            while (true)
            {
                bool isActive = false;
                Dispatcher.Invoke(() =>
                {
                    isActive = this.IsActive;

                });
                if (!isActive)
                    break;

                byte[] code = new byte[1];
                code[0] = (byte)(13);

                SocketClass.clientStream.Write(code, 0, code.Length);

                byte[] lenBytes = new byte[4];
                SocketClass.clientStream.Read(code, 0, 1);
                SocketClass.clientStream.Read(lenBytes, 0, 4);

                if (BitConverter.IsLittleEndian)
                    Array.Reverse(lenBytes);

                byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
                SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

                string data = Encoding.Default.GetString(dataRecv);
                GetRoomStateResponse roomState = JsonConvert.DeserializeObject<GetRoomStateResponse>(data);

                string[] players = roomState.players.Split(',');

                Dispatcher.Invoke(() =>
                {
                    ParticipantsGrid.Items.Clear();
                    foreach (string player in players)
                        ParticipantsGrid.Items.Add(roomState.players);
                });
                
                Thread.Sleep(3000);
            }
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }
    }
}

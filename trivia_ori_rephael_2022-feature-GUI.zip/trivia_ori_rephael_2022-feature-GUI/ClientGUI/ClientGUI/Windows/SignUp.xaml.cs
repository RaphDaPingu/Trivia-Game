﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;

namespace ClientGUI.Windows
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();

            this.Welcome.FontSize = 30;
            this.OK.FontSize = 20;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            SignUpRequest signupReq = new SignUpRequest(UsernameTextbox.Text, PasswordTextbox.Password, EmailTextbox.Text);

            string json = JsonConvert.SerializeObject(signupReq, Formatting.Indented);
            byte[] data = Encoding.ASCII.GetBytes(json);

            byte[] lenBytes = BitConverter.GetBytes(data.Length);

            byte[] code = new byte[1];
            code[0] = (byte)(2);
            
            byte[] msg = code.Concat(lenBytes).ToArray().Concat(data).ToArray();

            SocketClass.clientStream.Write(msg, 0, msg.Length);

            SocketClass.clientStream.Read(code, 0, 1);
            SocketClass.clientStream.Read(lenBytes, 0, 4);

            if (BitConverter.IsLittleEndian)
                Array.Reverse(lenBytes);

            byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];

            SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Window_Closed(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MainWindow win = new MainWindow();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }
    }
}

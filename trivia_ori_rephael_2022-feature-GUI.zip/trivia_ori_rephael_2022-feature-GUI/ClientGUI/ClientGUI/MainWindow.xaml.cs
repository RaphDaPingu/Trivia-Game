﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Net;
using System.Net.Sockets;
using ClientGUI.Windows;
using Newtonsoft.Json;

namespace ClientGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool ConnectionToServer()
        {
            SocketClass.client = new TcpClient();
            SocketClass.serverEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8826);

            try
            {
                SocketClass.client.Connect(SocketClass.serverEndPoint);
            }

            catch
            {
                return false;
            }

            SocketClass.clientStream = SocketClass.client.GetStream();

            return true;
        }

        public MainWindow()
        {
            while (true)
            {
                if (!SocketClass.IsConnected)
                {
                    if (!ConnectionToServer())
                    {
                        if (MessageBox.Show("You don't have a server running.\n\nOK - Try connecting again\nCancel - Give up and do something else", "Server is dead lol", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                        {
                            continue;
                        }

                        else
                        {
                            Environment.Exit(1);
                        }
                    }

                    else
                    {
                        SocketClass.IsConnected = true;

                        break;
                    }
                }

                else
                {
                    break;
                }
            }

            InitializeComponent();

            this.Welcome.FontSize = 30;

            if (SocketClass.username == "")
            {
                this.DisplayUsername.Content = "";

                this.UsernameTextbox.IsEnabled = true;
                this.PasswordTextbox.IsEnabled = true;
                this.Login.IsEnabled = true;

                this.SignUpButton.Content = "Sign Up";

                this.JoinRoomButton.IsEnabled = false;
                this.CreateRoomButton.IsEnabled = false;
                this.MyStatusButton.IsEnabled = false;
                this.BestScoresButton.IsEnabled = false;
            }

            else
            {
                this.DisplayUsername.Content = SocketClass.username;
                this.WelcomeUsername.Content = "Hello, " + SocketClass.username + "!";

                this.UsernameTextbox.IsEnabled = false;
                this.PasswordTextbox.IsEnabled = false;
                this.Login.IsEnabled = false;

                this.SignUpButton.Content = "Sign Out";

                this.JoinRoomButton.IsEnabled = true;
                this.CreateRoomButton.IsEnabled = true;
                this.MyStatusButton.IsEnabled = true;
                this.BestScoresButton.IsEnabled = true;
            }

            this.DisplayUsername.FontSize = 15;
            this.WelcomeUsername.FontSize = 15;
            this.ErrorMessage.FontSize = 15;

            this.SignUpButton.FontSize = 15;
            this.JoinRoomButton.FontSize = 15;
            this.CreateRoomButton.FontSize = 15;
            this.MyStatusButton.FontSize = 15;
            this.BestScoresButton.FontSize = 15;
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            // database from server
            
            string username = this.UsernameTextbox.Text;
            string password = this.PasswordTextbox.Text;

            if (username.Length == 0 && password.Length != 0)
            {
                this.ErrorMessage.Content = "Enter a username";
                this.UsernameTextbox.Focus();
            }

            else if (username.Length != 0 && password.Length == 0)
            {
                this.ErrorMessage.Content = "Enter a password";
                this.PasswordTextbox.Focus();
            }

            else if (username.Length == 0 && password.Length == 0)
            {
                this.ErrorMessage.Content = "Enter SOMETHING!!!";
                this.UsernameTextbox.Focus();
            }

            else
            {
                LoginRequest loginReq = new LoginRequest(UsernameTextbox.Text, PasswordTextbox.Text);

                string json = JsonConvert.SerializeObject(loginReq, Formatting.Indented);
                byte[] data = Encoding.ASCII.GetBytes(json);

                byte[] lenBytes = BitConverter.GetBytes(data.Length);

                byte[] code = new byte[1];
                code[0] = (byte)(1);

                byte[] msg = code.Concat(lenBytes).ToArray().Concat(data).ToArray();
                SocketClass.clientStream.Write(msg, 0, msg.Length);

                SocketClass.clientStream.Read(code, 0, 1);
                SocketClass.clientStream.Read(lenBytes, 0, 4);

                if (BitConverter.IsLittleEndian)
                    Array.Reverse(lenBytes);
                byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];
                SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);

                LoginResponse loginRes = JsonConvert.DeserializeObject<LoginResponse>(Encoding.Default.GetString(dataRecv));

                if (loginRes.status == 1)
                {
                    this.UsernameTextbox.Text = "";
                    this.PasswordTextbox.Text = "";

                    this.ErrorMessage.Content = "";

                    SocketClass.username = username; // save it in a different way?

                    this.DisplayUsername.Content = username;
                    this.WelcomeUsername.Content = "Hello, " + username + "!";

                    this.UsernameTextbox.IsEnabled = false;
                    this.PasswordTextbox.IsEnabled = false;
                    this.Login.IsEnabled = false;

                    this.SignUpButton.Content = "Sign Out";

                    this.JoinRoomButton.IsEnabled = true;
                    this.CreateRoomButton.IsEnabled = true;
                    this.MyStatusButton.IsEnabled = true;
                    this.BestScoresButton.IsEnabled = true;
                }

                else
                {
                    this.ErrorMessage.Content = "User " + this.UsernameTextbox.Text + " Doesn't\nexist / You're already\nsigned in / Passwords\ndon't match";
                }
            }
        }

        private void SignUp_Click(object sender, RoutedEventArgs e)
        {
            // differentiate between sign up and sign out features according to text as it's a constant, either "Sign Up" or "Sign Out"

            // sign out should probably just "reload" the MainWindow?

            if (this.SignUpButton.Content.ToString() == "Sign Up")
            {
                this.Hide();

                SignUp win = new SignUp();
                win.Top = this.Top;
                win.Left = this.Left;

                win.Show();
            }

            else
            {
                this.Hide();

                //this.DisplayUsername.Content = "";
                SocketClass.username = "";

                //string json = JsonConvert.SerializeObject(signupReq, Formatting.Indented);
                //byte[] data = Encoding.ASCII.GetBytes(json);

                //byte[] lenBytes = BitConverter.GetBytes(data.Length);

                byte[] code = new byte[1];
                code[0] = (byte)(4);

                //byte[] msg = code.Concat(lenBytes).ToArray().Concat(data).ToArray();

                SocketClass.clientStream.Write(code, 0, code.Length);
                //SocketClass.clientStream.Write(msg, 0, msg.Length);

                // we don't do anything with this

                /*
                SocketClass.clientStream.Read(code, 0, 1);
                SocketClass.clientStream.Read(lenBytes, 0, 4);

                if (BitConverter.IsLittleEndian)
                    Array.Reverse(lenBytes);

                byte[] dataRecv = new byte[BitConverter.ToInt32(lenBytes, 0)];

                SocketClass.clientStream.Read(dataRecv, 0, dataRecv.Length);
                */

                //this.UsernameTextbox.IsEnabled = true;
                //this.PasswordTextbox.IsEnabled = true;
                //this.Login.IsEnabled = true;

                //this.SignUpButton.Content = "Sign In";

                //this.JoinRoomButton.IsEnabled = false;
                //this.CreateRoomButton.IsEnabled = false;
                //this.MyStatusButton.IsEnabled = false;
                //this.BestScoresButton.IsEnabled = false;

                MainWindow win = new MainWindow();

                win.Top = this.Top;
                win.Left = this.Left;

                win.Show();
            }
        }

        private void JoinRoom_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            
            JoinRoom win = new JoinRoom();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void CreateRoom_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            CreateRoom win = new CreateRoom();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void MyStatus_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            MyStatus win = new MyStatus();
            win.Top = this.Top;
            win.Left = this.Left;
            
            win.Show();
        }

        private void BestScores_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            BestScores win = new BestScores();
            win.Top = this.Top;
            win.Left = this.Left;

            win.Show();
        }

        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }
    }
}

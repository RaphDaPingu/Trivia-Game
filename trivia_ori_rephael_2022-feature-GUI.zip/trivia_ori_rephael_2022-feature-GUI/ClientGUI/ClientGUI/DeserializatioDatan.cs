﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientGUI
{
    public class LoginResponse

    {
        public int status;
    }

    public class SignUpResponse
    {
        public int status;
    }

    public class LogoutResponse
    {
        public int status;
    }

    public class CreateRoomResponse
    {
        public int status;
    }

    public class CloseRoomResponse
    {
        public int status;
    }

    public class LeaveRoomResponse
    {
        public int status;
    }

    public class GetRoomStateResponse
    {
        public int status;
        public bool hasGameBegun;
        public string players;
        public int questionCount;
        public string answerTimeout;
    }

    public class JoinRoomResponse
    {
        public int status;
    }

    public class GetRoomsResponse
    {
        public string rooms;
    }

    public class GetPlayersInRoomResponse
    {
        public string playersInRoom;
    }

    public class GetHighScoresResponse
    {
        public string highScores;
    }

    public class GetPersonalStatsResponse
    {
        public string personalStats;
    }
    
}

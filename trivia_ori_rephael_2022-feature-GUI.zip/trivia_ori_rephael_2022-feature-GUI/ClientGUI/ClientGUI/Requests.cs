﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientGUI
{
    public class LoginRequest
    {
        public string username;
        public string password;

        public LoginRequest(string username, string password)
        {
            this.username = username;
            this.password = password;
        }
    }

    public class SignUpRequest
    {
        public string username;
        public string password;
        public string email;

        public SignUpRequest(string username, string password, string email)
        {
            this.username = username;
            this.password = password;
            this.email = email;
        }
    }

    public class CreateRoomRequest
    {
        public string roomName;
        public int maxPlayers;
        public int questionCount;
        public int answerTimeout;

        public CreateRoomRequest(string roomName, int maxPlayers, int questionCount, int answerTimeout)
        {
            this.roomName = roomName;
            this.maxPlayers = maxPlayers;
            this.questionCount = questionCount;
            this.answerTimeout = answerTimeout;
        }
    }

    public class JoinRoomRequest
    {
        public int roomID;

        public JoinRoomRequest(int roomID)
        {
            this.roomID = roomID;
        }
    }

    public class GetPlayersInRoomRequest
    {
        public int roomID;
        
        public GetPlayersInRoomRequest(int roomID)
        {
            this.roomID = roomID;
        }
    }

}

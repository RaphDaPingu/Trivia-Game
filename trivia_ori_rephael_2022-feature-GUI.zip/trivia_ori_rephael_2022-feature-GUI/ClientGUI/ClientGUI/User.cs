﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientGUI
{
    public class User
    {
        public string username { get; set; }

        public static List<User> LoadCollectionData()
        {
            List<User> users = new List<User>();

            users.Add(new User()
            {
                username = "Raphael"
            });

            users.Add(new User()
            {
                username = "Ori"
            });

            users.Add(new User()
            {
                username = "Hadi"
            });

            return (users);
        }
    }
}

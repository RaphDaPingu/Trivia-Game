﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace ClientGUI
{
    public static class SocketClass
    {
        public static TcpClient client;
        public static IPEndPoint serverEndPoint;
        public static NetworkStream clientStream;
        public static byte[] buffer;

        public static bool IsConnected = false;

        public static string username = "";
    }
}

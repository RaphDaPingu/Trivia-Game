#include "Room.h"

Room::Room()
{
}

Room::Room(RoomData roomData, LoggedUser loggedUser)
{
	this->m_metadata = roomData;
	this->addUser(loggedUser);
}

RoomData Room::getRoomData()
{
	return this->m_metadata;
}

bool Room::addUser(LoggedUser loggedUser)
{
	if (this->getRoomData().maxPlayers > m_users.size())
	{
		m_users.push_back(loggedUser);
		return true;
	}
	return false;
}

void Room::removeUser(LoggedUser loggedUser)
{
	for (std::vector<LoggedUser>::iterator it = m_users.begin(); it != m_users.end(); ++it)
	{
		if (it->getUsername() == loggedUser.getUsername())
		{
			m_users.erase(it);
			break;
		}
	}
}

std::vector<std::string> Room::getAllUsers()
{
	std::vector<std::string> usersList;
	for (std::vector<LoggedUser>::iterator it = m_users.begin(); it != m_users.end(); ++it)
	{
		usersList.push_back(it->getUsername());
	}

	return usersList;
}

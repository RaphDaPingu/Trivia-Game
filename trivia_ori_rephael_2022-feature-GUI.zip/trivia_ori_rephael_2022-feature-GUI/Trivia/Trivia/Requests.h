#pragma once

#include <iostream>
#include <nlohmann/json.hpp>
#include <vector>

class IRequestHandler;

using namespace std;
using json = nlohmann::json;

// v1.0.0

struct LoginRequest {
	std::string username;
	std::string password;
};

struct SignupRequest {
	std::string username;
	std::string password;
	std::string email;
};

// v2.0.0

struct CreateRoomRequest {
	std::string roomName;
	unsigned int maxPlayers;
	unsigned int questionCount;
	unsigned int answerTimeout; // how much time for each question
};

struct JoinRoomRequest {
	int roomID;
};

struct GetPlayersInRoomRequest {
	int roomID;
};

struct RequestInfo {
	int code;
	string timeReceived;
	unsigned char* buffer;
};

struct RequestResult{
	IRequestHandler* newHandler;
	std::vector<unsigned char> response;
};

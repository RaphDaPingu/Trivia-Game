#include <iostream>
#include "JsonResponsePacketDeserializer.h"

LoginRequest JsonResponsePacketDeserializer::deserializeLoginRequest(unsigned char* buffer)
{
	/*

	std::string username;
	std::string password;

	for (int i = 0; i < strlen((char*)(buffer)); i++)
	{
		if (buffer[i] == '"')
		{
			i++;

			//get username
			while (buffer[i] != '"')
			{
				username += buffer[i];
				i++;
			}

			i++;

			while (buffer[i] != '"')
				i++;
			i++;

			//get password
			while (buffer[i] != '"')
			{
				password += buffer[i];
				i++;
			}

			break;
		}
	}

	LoginRequest loginReq;

	loginReq.username = username;
	loginReq.password = password;

	return (loginReq);

	*/

	json j = json::parse(buffer);

	LoginRequest loginReq;

	loginReq.username = j["username"];
	loginReq.password = j["password"];

	return (loginReq);
}

SignupRequest JsonResponsePacketDeserializer::deserializeSignUpRequest(unsigned char* buffer)
{
	/*

	std::string username;
	std::string password;
	std::string email;

	for (int i = 0; i < strlen((char*)(buffer)); i++)
	{
		if (buffer[i] == '"')
		{
			i++;

			//get username
			while (buffer[i] != '"')
			{
				username += buffer[i];
				i++;
			}

			i++;

			while (buffer[i] != '"')
				i++;
			i++;

			//get password
			while (buffer[i] != '"')
			{
				password += buffer[i];
				i++;
			}

			i++;

			while (buffer[i] != '"')
				i++;
			i++;

			//get email
			while (buffer[i] != '"')
			{
				email += buffer[i];
				i++;
			}

			break;
		}
	}

	SignupRequest signUpReq;

	signUpReq.username = username;
	signUpReq.password = password;
	signUpReq.email = email;

	return (signUpReq);

	*/

	json j = json::parse(buffer);

	SignupRequest signUpReq;

	signUpReq.username = j["username"];
	signUpReq.password = j["password"];
	signUpReq.email = j["email"];

	return (signUpReq);
}

CreateRoomRequest JsonResponsePacketDeserializer::deserializeCreateRoomRequest(unsigned char* buffer) {
	json j = json::parse(buffer);

	CreateRoomRequest createRoomReq;

	createRoomReq.roomName = j["roomName"];
	createRoomReq.maxPlayers = j["maxPlayers"];
	createRoomReq.questionCount = j["questionCount"];
	createRoomReq.answerTimeout = j["answerTimeout"];

	return (createRoomReq);
}

JoinRoomRequest JsonResponsePacketDeserializer::deserializeJoinRoomRequest(unsigned char* buffer) {
	json j = json::parse(buffer);

	JoinRoomRequest joinRoomReq;

	joinRoomReq.roomID = j["roomID"];

	return (joinRoomReq);
}

GetPlayersInRoomRequest JsonResponsePacketDeserializer::deserializeGetPlayersInRoomRequest(unsigned char* buffer) {
	json j = json::parse(buffer);

	GetPlayersInRoomRequest getPlayersInRoomReq;

	getPlayersInRoomReq.roomID = j["roomID"];

	return (getPlayersInRoomReq);
}

#pragma once

#include <iostream>
#include <vector>
#include "Structs.h"
#include <bitset>

#define LOGIN 1
#define SIGNUP 2
#define ERROR 3
#define LOGOUT 4
#define GET_ROOMS 5
#define GET_PLAYERS_IN_ROOM 6
#define CREATE_ROOM 7
#define JOIN_ROOM 8
#define HIGH_SCORE 9
#define STATISTICS 10
#define CLOSE_ROOM 11
#define START_GAME 12
#define GET_ROOM_STATE 13
#define LEAVE_ROOM 14 

class JsonResponsePacketSerializer {
public:
	static std::vector<unsigned char> serializeLoginResponse(LoginResponse lr);
	static std::vector<unsigned char> serializeSignupResponse(SignupResponse sr);
	static std::vector<unsigned char> serializeErrorResponse(ErrorResponse er);
	static std::vector<unsigned char> serializeLogoutResponse(LogoutResponse lor);
	static std::vector<unsigned char> serializeGetRoomsResponse(GetRoomsResponse grr);
	static std::vector<unsigned char> serializeGetPlayersInRoomResponse(GetPlayersInRoomResponse gpirr);
	static std::vector<unsigned char> serializeCreateRoomResponse(CreateRoomResponse crr);
	static std::vector<unsigned char> serializeJoinRoomResponse(JoinRoomResponse jrr);
	static std::vector<unsigned char> serializeHighScoreResponse(GetHighScoreResponse hsr);
	static std::vector<unsigned char> serializeStatisticsResponse(GetPersonalStatsResponse str);
	static std::vector<unsigned char> serializeCloseRoomResponse(CloseRoomResponse clrr);
	static std::vector<unsigned char> serializeLeaveRoomResponse(LeaveRoomResponse lrr);
	static std::vector<unsigned char> serializeStartGameResponse(StartGameResponse sgr);
	static std::vector<unsigned char> serializeGetRoomStateResponse(GetRoomStateResponse grsr);

private:
};

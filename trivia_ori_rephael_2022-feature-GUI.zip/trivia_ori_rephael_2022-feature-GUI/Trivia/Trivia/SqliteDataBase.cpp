#include <iostream>
#include "SqliteDataBase.h"
#include <typeinfo>
#include <string>

bool searchRes = false;
std::string data;

std::vector<std::string> sqlData;

int searchMatch(void* data, int argc, char** argv, char** azColName)
{
    searchRes = (argc != 0);

    return 0;
}

int getDataFromSql(void* data, int argc, char** argv, char** azColName)
{
    data = argv[0];

    return 0;
}
int getBestScores(void* data, int argc, char** argv, char** azColName)
{
    sqlData.push_back(std::string(argv[0]) + ':' + std::string(argv[1]));

    return 0;
}

SqliteDataBase::SqliteDataBase()
{
	int file_exist = _access("triviaDB.sqlite", 0);
	int res = sqlite3_open("triviaDB.sqlite", &db);

	if (res != SQLITE_OK) {
		db = nullptr;
		std::cout << "Failed to open DB" << std::endl;
	}
	if (file_exist != 0) {
		// users

		const char* sqlStatement = "CREATE TABLE USERS "
			"(USERNAME TEXT PRIMARY KEY NOT NULL, "
			"PASSWORD TEXT NOT NULL, "
			"EMAIL TEXT NOT NULL);";
		char* errMessage = nullptr;

		res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
		if (res != SQLITE_OK)
			std::cerr << "SQL statement error";

		// questions

		sqlStatement = "CREATE TABLE QUESTIONS "
			"(QUESTION TEXT PRIMARY KEY NOT NULL, "
			"OPTION_ONE TEXT NOT NULL, "
			"OPTION_TWO TEXT NOT NULL, "
			"OPTION_THREE TEXT NOT NULL, "
			"OPTION_FOUR TEXT NOT NULL, "
			"CORRECT_ANSWER TEXT NOT NULL);";
		errMessage = nullptr;

		res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
		if (res != SQLITE_OK)
			std::cerr << "SQL statement error";

		// insert questions

		sqlStatement = "INSERT INTO QUESTIONS "
			"(QUESTION, OPTION_ONE, OPTION_TWO, OPTION_THREE, OPTION_FOUR, CORRECT_ANSWER) "
			"VALUES ('QUESTION 1', 'ANSWER 1A', 'ANSWER 1B', 'ANSWER 1C', 'ANSWER 1D', 'CORRECT ANSWER 1'), "
			"('QUESTION 2', 'ANSWER 2A', 'ANSWER 2B', 'ANSWER 2C', 'ANSWER 2D', 'CORRECT ANSWER 2'), "
			"('QUESTION 3', 'ANSWER 3A', 'ANSWER 3B', 'ANSWER 3C', 'ANSWER 3D', 'CORRECT ANSWER 3'), "
			"('QUESTION 4', 'ANSWER 4A', 'ANSWER 4B', 'ANSWER 4C', 'ANSWER 4D', 'CORRECT ANSWER 4'), "
			"('QUESTION 5', 'ANSWER 5A', 'ANSWER 5B', 'ANSWER 5C', 'ANSWER 5D', 'CORRECT ANSWER 5'), "
			"('QUESTION 6', 'ANSWER 6A', 'ANSWER 6B', 'ANSWER 6C', 'ANSWER 6D', 'CORRECT ANSWER 6'), "
			"('QUESTION 7', 'ANSWER 7A', 'ANSWER 7B', 'ANSWER 7C', 'ANSWER 7D', 'CORRECT ANSWER 7'), "
			"('QUESTION 8', 'ANSWER 8A', 'ANSWER 8B', 'ANSWER 8C', 'ANSWER 8D', 'CORRECT ANSWER 8'), "
			"('QUESTION 9', 'ANSWER 9A', 'ANSWER 9B', 'ANSWER 9C', 'ANSWER 9D', 'CORRECT ANSWER 9'), "
			"('QUESTION 10', 'ANSWER 10A', 'ANSWER 10B', 'ANSWER 10C', 'ANSWER 10D', 'CORRECT ANSWER 10');";
		errMessage = nullptr;

        res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
        if (res != SQLITE_OK)
            std::cerr << "SQL statement error";

		sqlStatement = "CREATE TABLE STATISTICS (USERNAME TEXT NOT NULL,"
            "score FLOAT NOT NULL, average_time FLOAT NOT NULL,"
			"correct_answers INTEGER NOT NULL, total_answers INTEGER NOT NULL,"
			"games_played INTEGER NOT NULL, FOREIGN KEY (USERNAME) REFERENCES USERS(USERNAME));";

		res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
		if (res != SQLITE_OK)
			std::cerr << "SQL statement error";
	}
}

SqliteDataBase::~SqliteDataBase()
{
    sqlite3_close(db);
	db = nullptr;
}

bool SqliteDataBase::doesUserExist(std::string username)
{
    std::string strSqlStatement = "SELECT * FROM USERS WHERE USERNAME = '" + username + "';";
    char** errMessage = nullptr;

    //std::cout << strSqlStatement << '\n' << strSqlStatement.c_str() << std::endl;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), searchMatch, nullptr, errMessage);

    //std::cout << res << std::endl;

    if (res != SQLITE_OK)
        std::cerr << "\nError - Couldn't figure out if the user exists\n";

	return searchRes;
}

bool SqliteDataBase::doesPasswordMatch(std::string username, std::string pass)
{
    std::string strSqlStatement = "SELECT * FROM USERS WHERE USERNAME = '" + username + "' AND PASSWORD = '" + pass + "';";
    char** errMessage = nullptr;

    //std::cout << strSqlStatement << '\n' << strSqlStatement.c_str() << std::endl;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), searchMatch, nullptr, errMessage);

    //std::cout << res << std::endl;

    if (res != SQLITE_OK)
        std::cerr << "\nError - Couldn't figure out if the passwords match\n";

    return searchRes;
}

void SqliteDataBase::addNewUser(std::string username, std::string pass, std::string email)
{
    std::string strSqlStatement = "INSERT INTO USERS "
        "(USERNAME, PASSWORD, EMAIL) "
        "VALUES ('" + username + "', '" + pass + "', '" + email + "');";
    char** errMessage = nullptr;

    //std::cout << strSqlStatement << '\n' << strSqlStatement.c_str() << std::endl;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), nullptr, nullptr, errMessage);

    //std::cout << res << std::endl;

    if (res != SQLITE_OK)
        std::cerr << "\nError - Couldn't add a new user\n";
}

float SqliteDataBase::getPlayerAverageAnswerTime(std::string username)
{
    std::string strSqlStatement = "SELECT average_time FROM STATISTICS WHERE USERNAME = '" + username + "';";
    char** errMessage = nullptr;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), getDataFromSql, nullptr, errMessage);

    if (res != SQLITE_OK)
    {
        std::cerr << "\nError - Couldn't add a new user\n";
        return -1;
    }

    return std::stof(data);   
}

int SqliteDataBase::getNumOfCorrectAnswers(std::string username)
{
    std::string strSqlStatement = "SELECT correct_answers FROM STATISTICS WHERE USERNAME = '" + username + "';";
    char** errMessage = nullptr;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), getDataFromSql, nullptr, errMessage);

    if (res != SQLITE_OK)
    {
        std::cerr << "\nError - Couldn't add a new user\n";
        return -1;
    }

    return std::stoi(data);
}

int SqliteDataBase::getNumOfTotalAnswers(std::string username)
{
    std::string strSqlStatement = "SELECT total_answers FROM STATISTICS WHERE USERNAME = '" + username + "';";
    char** errMessage = nullptr;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), getDataFromSql, nullptr, errMessage);

    if (res != SQLITE_OK)
    {
        std::cerr << "\nError - Couldn't add a new user\n";
        return -1;
    }

    return std::stoi(data);
}

int SqliteDataBase::getNumOfPlayerGames(std::string username)
{
    std::string strSqlStatement = "SELECT games_played FROM STATISTICS WHERE USERNAME = '" + username + "';";
    char** errMessage = nullptr;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), getDataFromSql, nullptr, errMessage);

    if (res != SQLITE_OK)
    {
        std::cerr << "\nError - Couldn't add a new user\n";
        return -1;
    }

    return std::stoi(data); 
}

std::vector<std::string> SqliteDataBase::getHighScores()
{
    std::string strSqlStatement = "SELECT username, score FROM STATISTICS ORDER BY score DESC LIMIT 3;";
    char** errMessage = nullptr;

    int res = sqlite3_exec(db, strSqlStatement.c_str(), getBestScores, nullptr, errMessage);

    if (res != SQLITE_OK)
    {
        std::cerr << "\nError - Couldn't add a new user\n";
    }

    return sqlData;
}




#include "JsonResponsePacketSerializer.h"
#include "RoomMemberRequestHandler.h"
#include "MenuRequestHandler.h"

RoomMemberRequestHandler::RoomMemberRequestHandler(Room room, LoggedUser loggedUser, RoomManager roomManager, RequestHandlerFactory requestHandlerFactory)
{
    m_room = room;
    m_user = loggedUser;
    m_roomManager = roomManager;
    m_handlerFactory = requestHandlerFactory;
}

    bool RoomMemberRequestHandler::isRequestRelevant(RequestInfo requestInfo)
{
    return requestInfo.code == 13 || requestInfo.code == 14;
}

RequestResult RoomMemberRequestHandler::handleRequest(RequestInfo requestInfo)
{
    RequestResult reqRes;


    switch (requestInfo.code)
    {
    case 13:
        reqRes = getRoomState();
        break;
    case 14:
        reqRes = leaveRoom();
        break;
    default:
        break;
    }
    return reqRes;
}

RequestResult RoomMemberRequestHandler::leaveRoom()
{
    RequestResult reqRes;

    m_room.removeUser(m_user);

    reqRes.response = JsonResponsePacketSerializer::serializeLeaveRoomResponse(LeaveRoomResponse());
    reqRes.newHandler = m_handlerFactory.createMenuRequestHandler(m_user);

    return reqRes;
}

RequestResult RoomMemberRequestHandler::getRoomState()
{
    GetRoomStateResponse grsr;
    RequestResult reqRes;


    if (m_roomManager.getRoomsMap().find(m_room.getRoomData().id) != m_roomManager.getRoomsMap().end())
    {
        grsr.j["hasGameBegun"] = m_room.getRoomData().isActive;
        if (m_room.getRoomData().isActive == 1)
        {
            reqRes.response = JsonResponsePacketSerializer::serializeStartGameResponse(StartGameResponse());
            reqRes.newHandler = nullptr;

            return reqRes;
        }

        grsr.j["questionCount"] = m_room.getRoomData().numOfQuestionInGame;

        std::string players;
        players = std::accumulate(m_room.getAllUsers().begin(), m_room.getAllUsers().end(), std::string(),
            [&players](std::string& x, std::string& y) {
                return x.empty() ? y : x + players + ", " + y; });

        grsr.j["players"] = players;

        reqRes.response = JsonResponsePacketSerializer::serializeGetRoomStateResponse(grsr);
        reqRes.newHandler = nullptr;

        return reqRes;
    }
    reqRes.response = JsonResponsePacketSerializer::serializeLeaveRoomResponse(LeaveRoomResponse());
    reqRes.newHandler = m_handlerFactory.createMenuRequestHandler(m_user);

    return reqRes;

    return RequestResult();
}

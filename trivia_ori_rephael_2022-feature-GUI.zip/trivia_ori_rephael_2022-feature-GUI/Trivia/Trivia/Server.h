#pragma once

#include "Communicator.h"
#include "SqliteDataBase.h"
#include "RequestHandlerFactory.h"

// Q: why do we need this class ?
// A: this is the main class which holds all the resources,
// accept new clients and handle them.
class Server
{
public:
	Server();
	~Server();
	void run();

private:
	RequestHandlerFactory m_handlerFactory;
	Communicator m_communicator;
	SqliteDataBase m_database;
};


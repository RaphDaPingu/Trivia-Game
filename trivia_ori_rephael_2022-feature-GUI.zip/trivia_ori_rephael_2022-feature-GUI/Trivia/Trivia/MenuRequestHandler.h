#pragma once

#include <iostream>

#include "IRequestHandler.h"
#include "Requests.h"
#include "RequestHandlerFactory.h"
#include "RoomManager.h"
#include "StatisticsManager.h"

class MenuRequestHandler : public IRequestHandler
{
public:
	MenuRequestHandler(RoomManager roomManager, StatisticsManager statisticsManager, RequestHandlerFactory requestHandlerFactory, LoggedUser loggedUser);
	~MenuRequestHandler();

	bool isRequestRelevant(RequestInfo requestInfo);
	RequestResult handleRequest(RequestInfo requestInfo);

	void setRoomManager(RoomManager& roomManager);
private:
	LoggedUser m_user;
	RoomManager m_roomManager;
	StatisticsManager m_statisticsManager;
	RequestHandlerFactory m_requestHandlerFactory;

	RequestResult logout();
	RequestResult getRooms();
	RequestResult getPlayersInRoom(RequestInfo requestInfo);
	RequestResult getPersonalStats(RequestInfo requestInfo);
	RequestResult getHighScore();
	RequestResult joinRoom(RequestInfo requestInfo);
	RequestResult createRoom(RequestInfo requestInfo);
};

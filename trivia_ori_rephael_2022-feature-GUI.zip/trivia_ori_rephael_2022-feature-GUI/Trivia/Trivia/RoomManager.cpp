#include "RoomManager.h"

RoomManager::RoomManager()
{
}

void RoomManager::createRoom(LoggedUser loggedUser, RoomData roomData)
{
	
	Room room = Room(roomData, loggedUser);
	this->m_rooms.insert(std::pair<int, Room>(roomData.id, room));
	
	/*
	Room room = Room(roomData, loggedUser);
	this->m_rooms.push_back(room);
	*/
}

void RoomManager::deleteRoom(int id)
{
	
	for (std::map<int, Room>::iterator it = this->m_rooms.begin(); it != this->m_rooms.end(); ++it)
	{
		if (it->first == id)
		{
			this->m_rooms.erase(id);
			break;
		}
	}
	/*
	for (std::vector<Room>::iterator it = m_rooms.begin(); it != m_rooms.end(); ++it)
	{
		if (it->getRoomData().id == id)
		{
			this->m_rooms.erase(it);
		}
	}
	*/
}

unsigned int RoomManager::getRoomState(int id)
{
	
	for (std::map<int, Room>::iterator it = this->m_rooms.begin(); it != this->m_rooms.end(); ++it)
	{
		if (it->first == id)
		{
			return it->second.getRoomData().isActive;
		}
	}
	
	/*
	for (std::vector<Room>::iterator it = m_rooms.begin(); it != m_rooms.end(); ++it)
	{
		if (it->getRoomData().id == id)
		{
			return it->getRoomData().isActive;
		}
	}
	*/
	
}

std::vector<RoomData> RoomManager::getRooms()
{
	
	std::vector<RoomData> rooms;
	for (std::map<int, Room>::iterator it = this->m_rooms.begin(); it != this->m_rooms.end(); ++it)
	{
		rooms.push_back(it->second.getRoomData());
	}

	return rooms;

	/*
	std::vector<RoomData> rooms;
	std::vector<Room> v = this->m_rooms;
	for (std::vector<Room>::iterator it = v.begin(); it != v.end(); ++it)
	{
		rooms.push_back(it->getRoomData());
	}
	return rooms;
	*/
}

Room RoomManager::getRoom(int id)
{
	
	for (std::map<int, Room>::iterator it = this->m_rooms.begin(); it != this->m_rooms.end(); ++it)
	{
		if (it->first == id)
			return it->second;
	}
	/*
	for (std::vector<Room>::iterator it = m_rooms.begin(); it != m_rooms.end(); ++it)
	{
		if (it->getRoomData().id == id)
		{
			return *it;
		}
	}
	*/
}

std::map<int, Room> RoomManager::getRoomsMap()
{
	return m_rooms;
}


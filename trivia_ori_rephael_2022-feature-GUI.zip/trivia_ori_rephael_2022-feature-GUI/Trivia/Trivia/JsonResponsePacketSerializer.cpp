#include <iostream>
#include "JsonResponsePacketSerializer.h"
#include <bitset>

vector<unsigned char> intToBytes(int paramInt)
{
	vector<unsigned char> arrayOfByte;

	for (int i = 0; i < 4; i++) {
		arrayOfByte.insert(arrayOfByte.begin(), paramInt >> (i * 8));
	}

	return (arrayOfByte);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeLoginResponse(LoginResponse lr){

	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(LOGIN));
	
	std::string json = lr.j.dump();
	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());

	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeSignupResponse(SignupResponse sr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(SIGNUP));

	std::string json = sr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());

	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeErrorResponse(ErrorResponse er) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(ERROR));

	std::string json = er.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeLogoutResponse(LogoutResponse lor) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(LOGOUT));

	std::string json = lor.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeGetRoomsResponse(GetRoomsResponse grr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(GET_ROOMS));

	// replace "" in json with a string that looks like this: "room1, room2, ..., roomN"


	std::string json = "{";
	std::string s = "";
	for (auto it = begin(grr.rooms); it != end(grr.rooms); ++it) {
		s += it->name + ":" + to_string(it->id) + ", ";
	}

	s.substr(0, s.size() - 2); // replace last space and comma (because of ", ")
	if (s.size() == 0){
		json += "NoRoomsAvailable:0";
	}

	json += s += '}';

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeGetPlayersInRoomResponse(GetPlayersInRoomResponse gpirr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(GET_PLAYERS_IN_ROOM));

	// replace "" in json with a string that looks like this: "player1, player2, ..., playerN"

	std::string replacementString = "";

	for (auto it = begin(gpirr.players); it != end(gpirr.players); ++it) {
		replacementString += *it + ", ";
	}

	replacementString.substr(0, replacementString.size() - 2);

	gpirr.j.at("Players in Room:") = replacementString;

	std::string json = gpirr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeCreateRoomResponse(CreateRoomResponse crr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(CREATE_ROOM));

	std::string json = crr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeJoinRoomResponse(JoinRoomResponse jrr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(JOIN_ROOM));

	std::string json = jrr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeHighScoreResponse(GetHighScoreResponse hsr) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(HIGH_SCORE));

	// replace "" in json with a string that looks like this: "highscoreInfo1, highscoreInfo2, ..., highscoreInfo3"

	std::string replacementString = "";

	for (auto it = begin(hsr.highScores); it != end(hsr.highScores); ++it) {
		replacementString += *it + ", ";
	}

	replacementString.substr(0, replacementString.size() - 2);

	hsr.j.at("High Scores:") = replacementString;

	std::string json = hsr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeStatisticsResponse(GetPersonalStatsResponse str) {
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(STATISTICS));

	// replace "" in json with a string that looks like this: "statisticsInfo1, statisticsInfo2, ..., statisticsInfo3"

	std::string replacementString = "";

	for (auto it = begin(str.statistics); it != end(str.statistics); ++it) {
		replacementString += *it + ", ";
	}

	replacementString.substr(0, replacementString.size() - 2);

	str.j.at("Personal Statistics:") = replacementString;

	std::string json = str.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeCloseRoomResponse(CloseRoomResponse clrr)
{
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(CLOSE_ROOM));

	std::string json = clrr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeLeaveRoomResponse(LeaveRoomResponse lrr)
{
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(LEAVE_ROOM));

	std::string json = lrr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeStartGameResponse(StartGameResponse sgr)
{
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(START_GAME));

	std::string json = sgr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

std::vector<unsigned char> JsonResponsePacketSerializer::serializeGetRoomStateResponse(GetRoomStateResponse grsr)
{
	std::vector<unsigned char> buffer;

	buffer.push_back((unsigned char)(GET_ROOM_STATE));

	std::string json = grsr.j.dump();

	std::vector<unsigned char> length_bytes = intToBytes(json.length());
	buffer.insert(buffer.end(), length_bytes.begin(), length_bytes.end());

	std::vector<unsigned char> json_content(json.begin(), json.end());
	buffer.insert(buffer.end(), json_content.begin(), json_content.end());
	return (buffer);
}

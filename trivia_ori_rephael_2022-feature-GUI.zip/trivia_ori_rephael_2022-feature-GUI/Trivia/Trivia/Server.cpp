#include "Server.h"
#include <exception>
#include <string>
#include <numeric>

// using static const instead of macros
static const unsigned short PORT = 8826;
static const unsigned int IFACE = 0;

using std::string;
using std::mutex;
using std::unique_lock;
using std::vector;

void consoleHandler() {
	std::string str = "";

	while (str != "EXIT")
		std::cin >> str;

	std::cerr << "\nServer terminated\n";
	exit(0);
}

Server::Server()
{
}

Server::~Server()
{
}

void Server::run()
{
	m_handlerFactory = RequestHandlerFactory(&m_database);
	Communicator m_communicator(m_handlerFactory);

	std::thread t_connector(&Communicator::startHandleRequests, &m_communicator);
	t_connector.detach();
	
	consoleHandler();
}

#pragma once

#include <iostream>
#include "IDataBase.h"
#include <vector>
#include "LoggedUser.h"
#include "Requests.h"
#include "Structs.h"

class LoginManager
{
public:
	LoginManager();
	LoginManager(IDatabase* m_database);

	bool signup(std::string username, std::string pass, std::string email);
	bool login(std::string username, std::string pass);
	void logout(std::string username);

	LoggedUser getLoggedUser(std::string username);	
private:
	IDatabase* m_database;
	std::vector<LoggedUser> m_loggedUsers;
};

#pragma once
#include <iostream>

struct RoomData
{
	unsigned int id;
	std::string name;
	unsigned int maxPlayers;
	unsigned int numOfQuestionInGame;
	unsigned int timePerQuestion;
	unsigned int isActive;
};

#include <iostream>
#include "LoginRequestHandler.h"
#include "MenuRequestHandler.h"
#include "JsonResponsePacketDeserializer.h"
#include "JsonResponsePacketSerializer.h"

#define SUCCESS 1
#define FAIL 0

LoginRequestHandler::LoginRequestHandler(LoginManager& loginManager, RequestHandlerFactory& handlerFactory) : m_loginManager(loginManager), m_handlerFactory(handlerFactory)
{
}

LoginRequestHandler::~LoginRequestHandler() {
}

bool LoginRequestHandler::isRequestRelevant(RequestInfo requestInfo) 
{
    return (requestInfo.code == 1 || requestInfo.code == 2);
}

RequestResult LoginRequestHandler::handleRequest(RequestInfo requestInfo) 
{
    RequestResult reqRes = RequestResult();   

    if (requestInfo.code == 1)
    {     
        LoginRequest loginReq = JsonResponsePacketDeserializer::deserializeLoginRequest(requestInfo.buffer);
        
        LoginResponse lr = LoginResponse();
        lr.j["status"] = 1;

        if (!m_loginManager.login(loginReq.username, loginReq.password)) {
            lr.j["status"] = 0;

            reqRes.newHandler = nullptr;
        }
        else {
            reqRes.newHandler = this->m_handlerFactory.createMenuRequestHandler(m_loginManager.getLoggedUser(loginReq.username));
        }
        reqRes.response = JsonResponsePacketSerializer::serializeLoginResponse(lr);   
    }

    else if (requestInfo.code == 2)
    {
        SignupRequest signUpReq = JsonResponsePacketDeserializer::deserializeSignUpRequest(requestInfo.buffer);
        
        SignupResponse sr = SignupResponse();
        sr.j["status"] = 1;

        if (!m_loginManager.signup(signUpReq.username, signUpReq.password, signUpReq.email)) {
            sr.j["status"] = 0;
            reqRes.newHandler = nullptr;
        }

        reqRes.response = JsonResponsePacketSerializer::serializeSignupResponse(sr);

        reqRes.newHandler = nullptr;
    }

    return reqRes;
}

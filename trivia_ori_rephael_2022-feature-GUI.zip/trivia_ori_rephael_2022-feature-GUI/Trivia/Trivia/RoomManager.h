#pragma once
#include "Room.h"
#include <map>

class RoomManager
{
public:
	RoomManager();
	void createRoom(LoggedUser loggedUser, RoomData roomData);
	void deleteRoom(int id);
	unsigned int getRoomState(int id);
	std::vector<RoomData> getRooms();
	Room getRoom(int id);
	std::map<int, Room> getRoomsMap();

private:
	std::map<int, Room> m_rooms;
};
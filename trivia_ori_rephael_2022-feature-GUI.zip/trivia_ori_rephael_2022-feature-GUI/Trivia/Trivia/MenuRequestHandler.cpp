#include <iostream>
#include "MenuRequestHandler.h"
#include "JsonResponsePacketDeserializer.h"
#include "JsonResponsePacketSerializer.h"
#include "RoomMemberRequestHandler.h"
#include "RoomAdminRequestHandler.h"

MenuRequestHandler::MenuRequestHandler(RoomManager roomManager, StatisticsManager statisticsManager, RequestHandlerFactory requestHandlerFactory, LoggedUser loggedUser)
{
	m_user = loggedUser;
	m_roomManager = roomManager;
	m_statisticsManager = statisticsManager;
	m_requestHandlerFactory = requestHandlerFactory;
}

MenuRequestHandler::~MenuRequestHandler()
{
}

bool MenuRequestHandler::isRequestRelevant(RequestInfo requsetInfo)
{
	return requsetInfo.code >= LOGOUT && requsetInfo.code <= STATISTICS;
}

RequestResult MenuRequestHandler::handleRequest(RequestInfo requestInfo)
{
	RequestResult reqRes;
	switch (requestInfo.code)
	{
	case LOGOUT:
		reqRes = logout();
		break;
	case GET_ROOMS:
		reqRes = getRooms();
		break;
	case GET_PLAYERS_IN_ROOM:
		reqRes = getPlayersInRoom(requestInfo);
		break;
	case STATISTICS:
		reqRes = getPersonalStats(requestInfo);
		break;
	case HIGH_SCORE:
		reqRes = getHighScore();
		break;
	case JOIN_ROOM:
		reqRes = joinRoom(requestInfo);
		break;
	case CREATE_ROOM:
		reqRes = createRoom(requestInfo);
		break;
	default:
		break;
	}
	return reqRes;
}

void MenuRequestHandler::setRoomManager(RoomManager& roomManager)
{
	m_roomManager = roomManager;
}

RequestResult MenuRequestHandler::logout()
{
	m_requestHandlerFactory.getLoginManager().logout(m_user.getUsername());
	
	RequestResult reqRes;
	reqRes.response = JsonResponsePacketSerializer::serializeLogoutResponse(LogoutResponse());
	
	reqRes.newHandler = nullptr;
	return reqRes;
}

RequestResult MenuRequestHandler::getRooms()
{
	RequestResult reqRes;

	GetRoomsResponse grRes;
	grRes.rooms = m_roomManager.getRooms();
	
	reqRes.response = JsonResponsePacketSerializer::serializeGetRoomsResponse(grRes);
	reqRes.newHandler = nullptr;

	return reqRes;
}

RequestResult MenuRequestHandler::getPlayersInRoom(RequestInfo requestInfo)
{
	GetPlayersInRoomRequest gpirr = JsonResponsePacketDeserializer::deserializeGetPlayersInRoomRequest(requestInfo.buffer);

	Room room = m_roomManager.getRoom(gpirr.roomID);
	GetPlayersInRoomResponse playersInRoomRes;

	playersInRoomRes.players = room.getAllUsers();

	RequestResult reqRes;
	reqRes.response = JsonResponsePacketSerializer::serializeGetPlayersInRoomResponse(playersInRoomRes);
	reqRes.newHandler = nullptr;

	return reqRes;
}

RequestResult MenuRequestHandler::getPersonalStats(RequestInfo requestInfo)
{
	RequestResult reqRes;

	GetPersonalStatsResponse ghsRes;
	ghsRes.statistics = m_statisticsManager.getUserStatistics(m_user.getUsername());

	reqRes.response = JsonResponsePacketSerializer::serializeStatisticsResponse(ghsRes);
	reqRes.newHandler = nullptr;

	return reqRes;
}

RequestResult MenuRequestHandler::getHighScore()
{
	RequestResult reqRes;
	GetHighScoreResponse ghsRes;
	ghsRes.highScores = m_statisticsManager.getHighScore();

	reqRes.response = JsonResponsePacketSerializer::serializeHighScoreResponse(ghsRes);
	reqRes.newHandler = nullptr;

	return reqRes;
}

RequestResult MenuRequestHandler::joinRoom(RequestInfo requestInfo)
{
	RequestResult reqRes;

	JoinRoomRequest jrReq = JsonResponsePacketDeserializer::deserializeJoinRoomRequest(requestInfo.buffer);

	reqRes.newHandler = m_requestHandlerFactory.createRoomMemberRequestHandler(m_user, m_roomManager.getRoom(jrReq.roomID));
	
	JoinRoomResponse jrRes;
	if (!m_roomManager.getRoom(jrReq.roomID).addUser(m_user))
	{
		jrRes.j["status"] = 0;
		reqRes.newHandler = nullptr;
	}

	reqRes.response = JsonResponsePacketSerializer::serializeJoinRoomResponse(jrRes);
	return reqRes;
}

RequestResult MenuRequestHandler::createRoom(RequestInfo requestInfo)
{
	RequestResult reqRes;
	CreateRoomResponse crr = CreateRoomResponse();
	try
	{
		CreateRoomRequest crReq = JsonResponsePacketDeserializer::deserializeCreateRoomRequest(requestInfo.buffer);

		RoomData roomData;
		roomData.name = crReq.roomName;
		roomData.maxPlayers = crReq.maxPlayers;
		roomData.numOfQuestionInGame = crReq.questionCount;
		roomData.timePerQuestion = crReq.answerTimeout;
		roomData.isActive = false;

		std::vector<RoomData> roomsData = m_roomManager.getRooms();
		if (roomsData.empty())
		{
			roomData.id = 1;
		}
		else
		{
			roomData.id = roomsData.back().id + 1;
		}
		m_requestHandlerFactory.getRoomManager().createRoom(m_user, roomData);
		
		crr.j["status"] = 1;
		reqRes.response = JsonResponsePacketSerializer::serializeCreateRoomResponse(crr);
		reqRes.newHandler = m_requestHandlerFactory.createRoomAdminRequestHandler(m_user, m_requestHandlerFactory.getRoomManager().getRoom(roomData.id));

		m_roomManager = m_requestHandlerFactory.getRoomManager();
	}
	catch (...)
	{
		crr.j["status"] = 0;
		reqRes.response = JsonResponsePacketSerializer::serializeCreateRoomResponse(crr);
		reqRes.newHandler = nullptr;
	}

	return reqRes;
}

#pragma warning(disable:4996)

#include <exception>
#include <string>
#include <numeric>
#include "LoginRequestHandler.h"
#include "RequestHandlerFactory.h"
#include "Communicator.h"
#include "Requests.h"
#include <bitset>
#include <math.h>
#include <ctime>
#include "Structs.h"
#include "JsonResponsePacketSerializer.h"
#include <sstream>
#include <chrono>

// using static const instead of macros
static const unsigned short PORT = 8826;
static const unsigned int IFACE = 0;

using std::string;
using std::mutex;
using std::vector;

#pragma warning(disable:4996)

Communicator::Communicator() : m_handlerFactory(m_handlerFactory)
{
}

Communicator::Communicator(RequestHandlerFactory& handlerFactory) : m_handlerFactory(handlerFactory)
{
	// notice that we step out to the global namespace
	// for the resolution of the function socket
	m_serverSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_serverSocket == INVALID_SOCKET)
		throw std::exception(__FUNCTION__ " - socket");
}

Communicator::~Communicator()
{
	TRACE(__FUNCTION__ " closing accepting socket");

	// why is this try necessary?

	try
	{
		// the only use of the destructor should be for freeing 
		// resources that was allocated in the constructor
		::closesocket(m_serverSocket);
	}

	catch (...) {}
}

void Communicator::startHandleRequests()
{
	bindAndListen();

	while (true)
	{
		// the main thread is only accepting clients 
		// and add then to the list of handlers
		TRACE("Waiting for clients...");

		SOCKET client_socket = accept(m_serverSocket, NULL, NULL);

		if (client_socket == INVALID_SOCKET)
			throw std::exception(__FUNCTION__);

		TRACE("\nClient accepted!");

		this->m_clients.insert({ client_socket, this->m_handlerFactory.createLoginRequestHandler() });

		// create new thread for client	and detach from it

		std::thread tr(&Communicator::handleNewClient, this, client_socket);
		tr.detach();
	}
}

void Communicator::bindAndListen()
{
	struct sockaddr_in sa = { 0 };
	sa.sin_port = htons(PORT);
	sa.sin_family = AF_INET;
	sa.sin_addr.s_addr = IFACE;
	// again stepping out to the global namespace
	if (::bind(m_serverSocket, (struct sockaddr*)&sa, sizeof(sa)) == SOCKET_ERROR)
		throw std::exception(__FUNCTION__ " - bind");
	TRACE("binded");

	if (::listen(m_serverSocket, SOMAXCONN) == SOCKET_ERROR)
		throw std::exception(__FUNCTION__ " - listen");
	TRACE("listening...");
}

void Communicator::handleNewClient(SOCKET clientSocket)
{
	IRequestHandler* requestHandler = this->m_clients.find(clientSocket)->second;
	RequestInfo reqInfo;

	try {
		while (true) {
			// Get the code

			char code[2];
			
			int res = recv(clientSocket, code, 1, 0);
			
			if (res == -1) {
				throw exception();
			}

			unsigned char codeBytes[1];
			std::copy(std::begin(code), std::end(code), std::begin(codeBytes));

			reqInfo.code = codeBytes[0];

			// Get time

			time_t now = time(NULL);
			std::stringstream oss;
			oss << std::put_time(localtime(&now), "%d/%m/%Y %H:%M:%S");
			reqInfo.timeReceived = oss.str();

			// Get the length

			if (reqInfo.code <= 2 || reqInfo.code == 6 || reqInfo.code == 7 || reqInfo.code == 8) {
				char len[5];
				res = recv(clientSocket, len, 4, 0);

				unsigned char lenBytes[4];
				std::copy(std::begin(len), std::end(len), std::begin(lenBytes));

				// Convert bytes to integer

				int length = (lenBytes[3] << 24 | lenBytes[2] << 16 | lenBytes[1] << 8 | lenBytes[0]);

				//int length = std::atoi((char*)(lenBytes));

				/*

				for (int i = 0; i < 4; i++) {
					std::bitset<8> bs(lenBytes[i]);
					std::string bits = bs.to_string();

					for (int j = 0; j < 8; j++)
					{
						length += int(bits[j]) * pow(2, (8 - j) * (4 - i) - 1);
					}
				}

				*/

				// Get the content

				char* data = new char[length + 1];
				res = recv(clientSocket, data, length, 0);

				unsigned char* dataBytes = new unsigned char[length + 1];
				std::copy(data, data + length, dataBytes);

				dataBytes[length] = '\0';

				reqInfo.buffer = dataBytes;

				std::cout << dataBytes << std::endl;
			}

			// Check if request is relevant

			if (!requestHandler->isRequestRelevant(reqInfo)) {
				std::vector<unsigned char> err = JsonResponsePacketSerializer::serializeErrorResponse(ErrorResponse());

				char* errRep = new char[err.size()];
				std::copy(err.begin(), err.end(), errRep);

				send(clientSocket, errRep, err.size(), 0);
			}

			// Handle the request

			else
			{
				RequestResult reqRes = requestHandler->handleRequest(reqInfo);

				if (reqRes.newHandler != nullptr) {
					requestHandler = reqRes.newHandler;
				}

				char* response = new char[reqRes.response.size()];
				std::copy(reqRes.response.begin(), reqRes.response.end(), response);

				send(clientSocket, response, reqRes.response.size(), 0);
			}
		}
	}
	
	catch (...) {
		std::cout << "\nClient " << clientSocket << " has disconnected\n";
		this->m_clients.erase(clientSocket);
		
	}
}

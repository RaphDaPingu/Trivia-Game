#pragma once
#include <iostream>
#include "LoggedUser.h"
#include <vector>
#include "DataStructs.h"

class Room 
{
public:
	Room();
	Room(RoomData roomData, LoggedUser loggedUser);
	RoomData getRoomData();
	bool addUser(LoggedUser loggedUser);
	void removeUser(LoggedUser loggedUser);
	std::vector<std::string> getAllUsers();

private:
	RoomData m_metadata;
	std::vector<LoggedUser> m_users;
};
#pragma once
#include <iostream>

#ifdef _DEBUG // vs add this define in debug mode
#include <stdio.h>
// Q: why do we need traces ?
// A: traces are a nice and easy way to detect bugs without even debugging
// or to understand what happened in case we miss the bug in the first time
#define TRACE(msg, ...) printf(msg "\n", __VA_ARGS__);
// for convenient reasons we did the traces in stdout
// in general we would do this in the error stream like that
// #define TRACE(msg, ...) fprintf(stderr, msg "\n", __VA_ARGS__);

#else // we want nothing to be printed in release version
#define TRACE(msg, ...) printf(msg "\n", __VA_ARGS__);
#define TRACE(msg, ...) // do nothing
#endif

#include <mutex>
#include <map>
#include <condition_variable>
#include <WinSock2.h>
#include "IRequestHandler.h"
#include "RequestHandlerFactory.h"

class Communicator
{
public:
	Communicator();
	Communicator(RequestHandlerFactory& handlerFactory);

	~Communicator();

	void startHandleRequests();
	
private:
	void bindAndListen();
	void handleNewClient(SOCKET clientSocket);

	std::map<SOCKET, IRequestHandler*> m_clients;
	RequestHandlerFactory& m_handlerFactory;
	SOCKET m_serverSocket;
};

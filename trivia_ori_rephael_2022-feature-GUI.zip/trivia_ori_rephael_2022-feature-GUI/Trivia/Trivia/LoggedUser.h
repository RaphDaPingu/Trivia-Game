#pragma once

#include <iostream>

class LoggedUser
{
public:
	LoggedUser() = default;
	LoggedUser(std::string username);
	~LoggedUser();

	std::string getUsername();
private:
	std::string m_username;
};

#pragma once

#include <iostream>
#include <vector>

class IDatabase
{
public:
	virtual bool doesUserExist(std::string username) = 0;
	virtual bool doesPasswordMatch(std::string username,std::string pass) = 0;
	virtual void addNewUser(std::string username, std::string pass, std::string email) = 0;
	virtual float getPlayerAverageAnswerTime(std::string username) = 0;
	virtual int getNumOfCorrectAnswers(std::string username) = 0;
	virtual int getNumOfTotalAnswers(std::string username) = 0;
	virtual int getNumOfPlayerGames(std::string username) = 0; 
	virtual std::vector<std::string> getHighScores() = 0;
};
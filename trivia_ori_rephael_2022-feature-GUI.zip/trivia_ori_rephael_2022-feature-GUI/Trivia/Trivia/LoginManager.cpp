#include "LoginManager.h"
#include "SqliteDataBase.h"

LoginManager::LoginManager()
{
}

LoginManager::LoginManager(IDatabase* database)
{
	this->m_database = database;
}

bool LoginManager::signup(std::string username, std::string pass, std::string email)
{
	if (!m_database->doesUserExist(username))
	{
		m_database->addNewUser(username, pass, email);

		return true;
	}

	return false;
}

bool LoginManager::login(std::string username, std::string pass)
{
	bool isLogged = false;

	if (m_database->doesUserExist(username) && m_database->doesPasswordMatch(username, pass))
	{
		for (std::vector<LoggedUser>::iterator it = m_loggedUsers.begin(); it != m_loggedUsers.end(); ++it)
		{
			if ((*it).getUsername() == username)
			{
				isLogged = true;

				break;
			}
		}

		if (!isLogged)
		{
			m_loggedUsers.push_back(LoggedUser(username));
			return true;
		}
	}

	return false;
}

void LoginManager::logout(std::string username)
{
	for (std::vector<LoggedUser>::iterator it = m_loggedUsers.begin(); it != m_loggedUsers.end(); ++it)
	{
		if ((*it).getUsername() == username)
		{
			m_loggedUsers.erase(it);
			break;
		}
	}
}

LoggedUser LoginManager::getLoggedUser(std::string username)
{
	for (std::vector<LoggedUser>::iterator it = m_loggedUsers.begin(); it != m_loggedUsers.end(); ++it)
	{
		if (it->getUsername() == username)
		{
			return *it;
		}
	}
}

#include <iostream>
#include "RequestHandlerFactory.h"
#include "LoginRequestHandler.h"
#include "MenuRequestHandler.h"
#include "RoomMemberRequestHandler.h"
#include "RoomAdminRequestHandler.h"

RequestHandlerFactory::~RequestHandlerFactory() {
}

RequestHandlerFactory::RequestHandlerFactory()
{
}

RequestHandlerFactory::RequestHandlerFactory(IDatabase* database) 
{
    this->m_database = database;
    m_loginManager = LoginManager(database);
    m_roomManager = RoomManager();
    m_statisticsManager = StatisticsManager(database);
}

LoginRequestHandler* RequestHandlerFactory::createLoginRequestHandler()
{
    return new LoginRequestHandler(m_loginManager, *this);
}

MenuRequestHandler* RequestHandlerFactory::createMenuRequestHandler(LoggedUser loggedUser)
{
    return new MenuRequestHandler(m_roomManager, m_statisticsManager, *this, loggedUser);
}

RoomMemberRequestHandler* RequestHandlerFactory::createRoomMemberRequestHandler(LoggedUser loggedUser, Room room)
{
    return new RoomMemberRequestHandler(room, loggedUser, m_roomManager , *this);
}

RoomAdminRequestHandler* RequestHandlerFactory::createRoomAdminRequestHandler(LoggedUser loggedUser, Room room)
{
    return new RoomAdminRequestHandler(room, loggedUser, m_roomManager, *this);
}

LoginManager& RequestHandlerFactory::getLoginManager() {
    return m_loginManager;
}

RoomManager& RequestHandlerFactory::getRoomManager()
{
    return m_roomManager;
}

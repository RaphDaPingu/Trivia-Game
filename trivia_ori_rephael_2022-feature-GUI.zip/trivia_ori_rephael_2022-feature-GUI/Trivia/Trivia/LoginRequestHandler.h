#pragma once

#include <iostream>
#include "Structs.h"
#include "Requests.h"
#include "RequestHandlerFactory.h"
#include "IRequestHandler.h"
#include "LoginManager.h"

class LoginRequestHandler : public IRequestHandler
{
public:
	LoginRequestHandler(LoginManager& loginManager, RequestHandlerFactory& handlerFactory);
	~LoginRequestHandler();

	bool isRequestRelevant(RequestInfo requestInfo);
	RequestResult handleRequest(RequestInfo requestInfo);
private:
	LoginManager& m_loginManager;
	RequestHandlerFactory& m_handlerFactory;
};
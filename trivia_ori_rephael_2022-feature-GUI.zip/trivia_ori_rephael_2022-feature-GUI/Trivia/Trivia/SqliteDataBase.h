#pragma once
#include "IDataBase.h"
#include "sqlite3.h"
#include <io.h>
#include <list>
#include <vector>

class SqliteDataBase : public IDatabase 
{
public:
	SqliteDataBase();
	~SqliteDataBase();

	bool doesUserExist(std::string username);
	bool doesPasswordMatch(std::string username, std::string pass);
	void addNewUser(std::string username, std::string pass, std::string email);

	//List<Question>getQuestions(int)
	float getPlayerAverageAnswerTime(std::string username);
	int getNumOfCorrectAnswers(std::string username);
	int getNumOfTotalAnswers(std::string username);
	int getNumOfPlayerGames(std::string username);
	std::vector<std::string> getHighScores();
	//int getPlayerScore(std::string username);

private:
	sqlite3* db;
};

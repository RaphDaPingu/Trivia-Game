#pragma once

#include <iostream>
#include <nlohmann/json.hpp>
#include "DataStructs.h"
#include <vector>

using namespace std;
using json = nlohmann::json;

// v1.0.0

struct LoginResponse {
	json j = json
	{ 
		{"status", 1}
	};
};

struct SignupResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct ErrorResponse {
	json j = json
	{
		{"message", "ERROR"}
	};
};

// v2.0.0

struct LogoutResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct CreateRoomResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct CloseRoomResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct StartGameResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct LeaveRoomResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct GetRoomStateResponse {
	json j = json
	{
		{"status", 1},
		{"HasGameBegun", 0},
		{"players", ""},
		{"questionCount", 1},
		{"answerTimeout", 0}
	};
};

struct JoinRoomResponse {
	json j = json
	{
		{"status", 1}
	};
};

struct GetRoomsResponse {
	std::vector<RoomData> rooms;

};

struct GetPlayersInRoomResponse {
	std::vector<std::string> players;

	json j = json
	{
		{"Players in Room:", ""}
	};
};

struct GetHighScoreResponse {
	std::vector<std::string> highScores;

	json j = json
	{
		{"High Scores:", ""}
	};
};

struct GetPersonalStatsResponse {
	std::vector<std::string> statistics;

	json j = json
	{
		{"Personal Statistics:", ""}
	};
};

#pragma once

#include "IDataBase.h"
#include <vector>

class StatisticsManager
{
public:
	StatisticsManager();
	StatisticsManager(IDatabase* database);

	std::vector<std::string> getHighScore();
	std::vector<std::string> getUserStatistics(std::string username);

private:
	IDatabase* m_database;
};

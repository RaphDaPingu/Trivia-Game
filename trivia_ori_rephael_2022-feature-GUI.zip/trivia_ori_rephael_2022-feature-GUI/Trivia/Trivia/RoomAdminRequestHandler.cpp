#include "RoomAdminRequestHandler.h"
#include "JsonResponsePacketSerializer.h"
#include "MenuRequestHandler.h"

RoomAdminRequestHandler::RoomAdminRequestHandler(Room room, LoggedUser loggedUser, RoomManager roomManager, RequestHandlerFactory requestHandlerFactory)
{
    m_room = room;
    m_user = loggedUser;
    m_roomManager = roomManager;
    m_handlerFactory = requestHandlerFactory;
}

bool RoomAdminRequestHandler::isRequestRelevant(RequestInfo requestInfo)
{
    return requestInfo.code >= 11 && requestInfo.code <= 13;
}

RequestResult RoomAdminRequestHandler::handleRequest(RequestInfo requestInfo)
{
    RequestResult reqRes;


    switch (requestInfo.code)
    {
    case 11:
        reqRes = closeRoom();
        break;
    case 12:
        reqRes = startGame();
        break;
    case 13:
        reqRes = getRoomState();
        break;
    default:
        break;
    }
    return reqRes;
}

RequestResult RoomAdminRequestHandler::closeRoom()
{
    RequestResult reqRes;

    m_roomManager.deleteRoom(m_room.getRoomData().id);
    m_room.~Room();

    reqRes.response = JsonResponsePacketSerializer::serializeCloseRoomResponse(CloseRoomResponse());
    reqRes.newHandler = m_handlerFactory.createMenuRequestHandler(m_user);

    return reqRes;
}

RequestResult RoomAdminRequestHandler::startGame()
{
    RoomData roomData = m_room.getRoomData();
    roomData.isActive = 1;

    RequestResult reqRes;
    reqRes.response = JsonResponsePacketSerializer::serializeStartGameResponse(StartGameResponse());
    reqRes.newHandler = nullptr;
    
    return reqRes;
}


RequestResult RoomAdminRequestHandler::getRoomState()
{
    GetRoomStateResponse grsr;

    grsr.j["hasGameBegun"] = m_room.getRoomData().isActive;
    grsr.j["questionCount"] = m_room.getRoomData().numOfQuestionInGame;

    std::string players;
    std::vector<std::string> playersInRoom = m_room.getAllUsers();

    players = std::accumulate(playersInRoom.begin(), playersInRoom.end(), std::string(),
        [&players](std::string& x, std::string& y) {
            return x.empty() ? y : x + players + ", " + y; });

    grsr.j["players"] = players;

    RequestResult reqRes;
    reqRes.response = JsonResponsePacketSerializer::serializeGetRoomStateResponse(grsr);
    reqRes.newHandler = nullptr;


    return reqRes;
}
